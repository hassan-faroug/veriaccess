import { Button } from "@/components/ui/button";
import { Shield, Lock, CheckCircle, Clock } from "lucide-react";
import { useLocation } from "wouter";

export default function Welcome() {
  const [, setLocation] = useLocation();

  const handleCreateSecureCode = () => {
    setLocation('/dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md mx-auto">
        
        {/* Header - Logo, Title and Subtitle */}
        <div className="text-center mb-16 px-6">
          {/* App Logo */}
          <div className="mb-12">
            <div className="w-20 h-20 mx-auto bg-[var(--trust-blue)] rounded-2xl flex items-center justify-center mb-6 shadow-lg">
              <Shield className="w-10 h-10 text-white" />
            </div>
          </div>
          
          {/* Main Title */}
          <h1 className="text-4xl md:text-5xl font-bold text-[var(--dark-slate)] mb-6 leading-tight">
            Welcome to
            <span className="text-[var(--trust-blue)] block mt-2">VeriAccess</span>
          </h1>
          
          {/* Subtitle */}
          <p className="text-lg md:text-xl text-slate-600 leading-relaxed font-medium">
            Let's secure your first door with a single touch
          </p>
        </div>
        
        {/* Primary Action Section */}
        <div className="px-6">
          {/* Primary Action Button */}
          <Button 
            onClick={handleCreateSecureCode}
            className="w-full bg-[var(--trust-blue)] hover:bg-blue-700 text-white font-semibold text-lg py-6 px-8 h-auto rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-[1.02] transition-all duration-200 ease-out focus:outline-none focus:ring-4 focus:ring-blue-300 focus:ring-opacity-50"
          >
            Create My Secure Door Code
          </Button>
          
          {/* Secondary helpful text */}
          <p className="text-center text-slate-500 text-sm mt-6 leading-relaxed">
            Quick setup • Bank-level security • No monthly fees
          </p>
        </div>
        
        {/* Trust Indicators */}
        <div className="mt-16 px-6">
          <div className="flex items-center justify-center space-x-8 text-slate-400">
            {/* Security badge */}
            <div className="flex items-center space-x-2">
              <Lock className="w-5 h-5" />
              <span className="text-xs font-medium">Encrypted</span>
            </div>
            
            {/* Privacy badge */}
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5" />
              <span className="text-xs font-medium">Private</span>
            </div>
            
            {/* Fast setup badge */}
            <div className="flex items-center space-x-2">
              <Clock className="w-5 h-5" />
              <span className="text-xs font-medium">2 min setup</span>
            </div>
          </div>
        </div>
        
      </div>
    </div>
  );
}
