import { ChevronRight, MapPin } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useState, useEffect, useRef } from "react";
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default markers in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface Location {
  lat: number;
  lng: number;
}

// Draggable marker component
function DraggableMarker({ position, onPositionChange }: { 
  position: Location; 
  onPositionChange: (newPosition: Location) => void; 
}) {
  const markerRef = useRef<L.Marker>(null);

  const eventHandlers = {
    dragend() {
      const marker = markerRef.current;
      if (marker != null) {
        const newPosition = marker.getLatLng();
        onPositionChange({
          lat: newPosition.lat,
          lng: newPosition.lng
        });
      }
    },
  };

  return (
    <Marker
      draggable={true}
      eventHandlers={eventHandlers}
      position={[position.lat, position.lng]}
      ref={markerRef}
    />
  );
}

export default function Dashboard() {
  const [currentStep, setCurrentStep] = useState(0); // 0: banner, 1: door name, 2: geo-lock, 3: account security
  const [doorName, setDoorName] = useState("");
  const [pinLocation, setPinLocation] = useState<Location>({ lat: 51.505, lng: -0.09 }); // Default to London
  const [email, setEmail] = useState("");

  const handleBannerClick = () => {
    setCurrentStep(1);
  };

  const handleNext = () => {
    if (currentStep === 1) {
      setCurrentStep(2);
      // Request location permission when moving to step 2
      requestLocationPermission();
    }
  };

  const requestLocationPermission = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const location = {
            lat: position.coords.latitude,
            lng: position.coords.longitude
          };
          setPinLocation(location);
        },
        (error) => {
          console.error('Error getting location:', error);
          // Keep default London location if permission denied
        }
      );
    }
  };

  const handleConfirmLocation = () => {
    console.log('Door name:', doorName);
    console.log('Pin location:', pinLocation);
    setCurrentStep(3);
  };

  const handleMarkerDrag = (newPosition: Location) => {
    setPinLocation(newPosition);
  };

  const handleSendVerificationCode = () => {
    console.log('Email:', email);
    console.log('Door name:', doorName);
    console.log('Pin location:', pinLocation);
    // TODO: Send verification code and proceed to final step
  };

  return (
    <div className="min-h-screen bg-background p-4">
      <div className="w-full max-w-md mx-auto pt-8">
        
        {/* Main Title */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Your Secure Code
          </h1>
        </div>
        
        {/* QR Code Placeholder */}
        <div className="flex justify-center mb-8">
          <div className="w-64 h-64 bg-white border-2 border-border rounded-2xl flex items-center justify-center shadow-lg">
            {/* QR Code Pattern - Simple placeholder */}
            <div className="w-48 h-48 grid grid-cols-8 gap-1">
              {/* Create a simple QR-like pattern */}
              {Array.from({ length: 64 }, (_, i) => (
                <div
                  key={i}
                  className={`
                    w-full h-full rounded-sm
                    ${Math.random() > 0.5 ? 'bg-foreground' : 'bg-background'}
                  `}
                />
              ))}
            </div>
          </div>
        </div>
        
        {/* Step-based Content */}
        {currentStep === 0 && (
          /* Clickable Call-to-Action Banner */
          <Alert 
            className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800 mb-6 cursor-pointer hover:bg-blue-100 dark:hover:bg-blue-950/30 transition-all duration-200 hover:shadow-md"
            onClick={handleBannerClick}
          >
            <div className="flex items-center justify-between w-full">
              <AlertDescription className="text-blue-800 dark:text-blue-200 font-semibold text-lg flex-1">
                Start Activation Now
              </AlertDescription>
              <ChevronRight className="h-6 w-6 text-blue-600 dark:text-blue-400 ml-4" />
            </div>
          </Alert>
        )}

        {currentStep === 1 && (
          /* Door Name Form - Step 1 */
          <div className="bg-card border border-border rounded-lg p-6 mb-6 shadow-sm">
            <h2 className="text-xl font-semibold text-foreground mb-2">
              Step 1: Name Your Door
            </h2>
            <p className="text-muted-foreground text-sm mb-4">
              This name will be shown to visitors to confirm they are at the right place.
            </p>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="doorName" className="text-sm font-medium">
                  Door Name
                </Label>
                <Input
                  id="doorName"
                  placeholder="e.g., Main Entrance, Apartment 5B"
                  value={doorName}
                  onChange={(e) => setDoorName(e.target.value)}
                  className="w-full"
                />
              </div>
              <Button 
                onClick={handleNext}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                disabled={!doorName.trim()}
              >
                Next
              </Button>
            </div>
          </div>
        )}

        {currentStep === 2 && (
          /* Geo-Lock Form - Step 2 */
          <div className="bg-card border border-border rounded-lg p-6 mb-6 shadow-sm">
            <h2 className="text-xl font-semibold text-foreground mb-2">
              Step 2: Activate Geo-Lock™
            </h2>
            <p className="text-muted-foreground text-sm mb-4">
              Confirm your door's exact location on the map. You can drag the pin to make adjustments.
            </p>
            <div className="space-y-4">
              {/* Interactive Leaflet Map */}
              <div className="w-full h-64 rounded-lg border border-border overflow-hidden">
                <MapContainer
                  center={[pinLocation.lat, pinLocation.lng]}
                  zoom={13}
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <DraggableMarker 
                    position={pinLocation} 
                    onPositionChange={handleMarkerDrag}
                  />
                </MapContainer>
              </div>
              
              {/* Coordinates Display */}
              <div className="bg-muted p-3 rounded-lg text-sm text-muted-foreground">
                <strong>Current Location:</strong> {pinLocation.lat.toFixed(6)}, {pinLocation.lng.toFixed(6)}
              </div>
              
              <Button 
                onClick={handleConfirmLocation}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Confirm Location & Activate Geo-Lock™
              </Button>
            </div>
          </div>
        )}

        {currentStep === 3 && (
          /* Account Security Form - Step 3 */
          <div className="bg-card border border-border rounded-lg p-6 mb-6 shadow-sm">
            <h2 className="text-xl font-semibold text-foreground mb-2">
              Final Step: Secure Your Account
            </h2>
            <p className="text-muted-foreground text-sm mb-4">
              This is for your security and to help you recover your account if you lose your phone. We will never share this information.
            </p>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium">
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="example@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full"
                />
              </div>
              <Button 
                onClick={handleSendVerificationCode}
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                disabled={!email.trim()}
              >
                Send Verification Code
              </Button>
            </div>
          </div>
        )}
        
      </div>
    </div>
  );
}