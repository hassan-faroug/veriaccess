# VeriAccess - Secure Door Access Application

## Overview

VeriAccess is a door security application built with a modern full-stack architecture. The application provides secure door access management with bank-level security and no monthly fees. It features a React frontend with TypeScript, an Express.js backend, and uses PostgreSQL with Drizzle ORM for data persistence.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for build tooling
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (TanStack Query) for server state and caching
- **Form Handling**: React Hook Form with Zod validation resolvers

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with /api prefix for all endpoints
- **Development**: Hot reload with tsx for development server
- **Production**: Compiled to ESM with esbuild

### Data Storage
- **Database**: PostgreSQL with Neon serverless driver
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema**: Shared TypeScript schema definitions between client and server
- **Migrations**: Drizzle Kit for database schema management
- **Session Storage**: PostgreSQL-based session storage with connect-pg-simple

### Authentication & Authorization
- **Session Management**: Express sessions with PostgreSQL session store
- **User Schema**: Basic user table with username/password fields
- **Validation**: Zod schemas for request/response validation
- **Security**: CORS and credential handling for API requests

### External Dependencies
- **Database**: Neon PostgreSQL serverless database
- **UI Components**: Radix UI primitives for accessibility and behavior
- **Icons**: Lucide React for consistent iconography
- **Date Handling**: date-fns for date manipulation
- **Styling**: Tailwind CSS with class-variance-authority for component variants
- **Development Tools**: Replit-specific plugins for development environment integration

### Key Design Decisions
- **Monorepo Structure**: Client, server, and shared code in a single repository
- **Type Safety**: End-to-end TypeScript with shared schemas
- **Component Architecture**: Reusable UI components with consistent styling
- **Database Design**: Simple user authentication with room for expansion
- **Build System**: Separate builds for client (Vite) and server (esbuild)
- **Development Experience**: Hot reload and error overlay for rapid development